# Retail Sales Analysis (Python)

An end-to-end sales analytics project: clean the data, calculate business KPIs, find what drives (and hurts) profit, and turn it into recommendations a manager can act on.

Built with **Python, pandas and matplotlib**.

## Business problem

A retail business sells Technology, Furniture and Office Supplies across five regions of India. Sales are growing, but the profit margin is thin. The questions this project answers:

1. How are sales and profit trending over time?
2. Which categories, sub-categories and regions make or lose money?
3. How much do discounts affect profitability?
4. How dependent is the business on a few customers?

## Dataset

`data/sales_data.csv` has about 5,600 order lines (3,000 orders, Jan 2023 to Dec 2024), with amounts in INR.

> **Note:** the data is **synthetic** (simulated sample data with realistic patterns such as festive-season peaks and discounts reducing margin). The findings below describe this simulated business, not a real company. The columns follow the popular Kaggle "Superstore" dataset, so you can swap in that file and re-run the script (you may need to adjust the date format and currency labels).

| Column | Meaning |
| --- | --- |
| Order ID, Order Date, Ship Date, Ship Mode | Order and delivery details |
| Customer ID, Segment | Who bought (Consumer, Corporate, Home Office) |
| Region, State | Where it was sold |
| Category, Sub-Category, Product Name | What was sold |
| Sales, Quantity, Discount, Profit | Money and volume |

## Key findings

| Metric | Value |
| --- | --- |
| Total sales | ₹6.09 Cr |
| Total profit | ₹49.7 L (8.2% margin) |
| Orders / customers | 3,000 / 604 |
| Average order value | ₹20,294 |

- **Growth:** sales grew 15% from 2023 to 2024.
- **Seasonality:** October to December brings 36% of all sales. The best month was November 2024 (₹42.5 L).
- **Categories:** Technology leads on sales, but Office Supplies earns the best margin (16.5%). Furniture is the weakest (2.5%).
- **Loss-makers:** Tables (-₹6.2 L) and Machines (-₹1.0 L) lose money overall.
- **Regions:** West has the best margin (10.2%); East has the weakest (3.6%).
- **Discounts:** line items with 30% or more discount (19% of the total) have a **-5.4% margin**, versus 10.7% for the rest.
- **Customers:** the top 10 customers account for 32% of sales.

### Recommendations

- Cap discounts at around 20% and require approval for anything deeper.
- Review pricing and discounting on Tables and Machines before the next festive season.
- Plan stock and marketing around October to December demand.
- Investigate why East margins lag (likely heavier discounting) and set regional discount limits.
- Run a loyalty or key-account programme for the top customers.

A written summary is also available in [`outputs/insights.md`](outputs/insights.md).

## Charts

![Monthly trend](images/01_monthly_trend.png)
![Category](images/02_category_sales_profit.png)
![Sub-category profit](images/03_subcategory_profit.png)
![Region performance](images/04_region_performance.png)
![Discount vs margin](images/05_discount_vs_margin.png)
![Top customers](images/06_top_customers.png)

## Project structure

```
sales-analysis-project/
├── data/
│   └── sales_data.csv        # dataset
├── src/
│   └── analysis.py           # data checks, KPIs, charts, insights
├── images/                   # charts produced by analysis.py
├── outputs/
│   └── insights.md           # written summary of findings
├── requirements.txt
├── LICENSE
└── README.md
```

## How to run

```bash
# 1. Clone the repo
git clone https://github.com/<your-username>/sales-analysis-project.git
cd sales-analysis-project

# 2. (Optional) create a virtual environment
python -m venv venv
source venv/bin/activate        # Windows: venv\Scripts\activate

# 3. Install dependencies
pip install -r requirements.txt

# 4. Run the analysis (from the main project folder)
python src/analysis.py
```

The script prints the KPIs and insights on screen and saves the charts to `images/`.

## What I did

1. **Data checks:** missing values, duplicates, date parsing.
2. **New columns:** year, month, delivery days.
3. **KPIs:** sales, profit, margin, orders, customers, average order value.
4. **Analysis:** time trend, category and sub-category profitability, regional performance, discount impact, customer concentration.
5. **Recommendations:** converted the numbers into actions.

## Next steps

- Customer segmentation using RFM (recency, frequency, monetary value).
- Sales forecasting for the next quarter.
- An interactive dashboard in Streamlit or Power BI.

## Author

**Your Name** · PGDM Student
[LinkedIn](https://www.linkedin.com/in/your-profile) · [GitHub](https://github.com/your-username)

Released under the [MIT License](LICENSE).
