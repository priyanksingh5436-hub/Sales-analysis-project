# Key insights

## Headline numbers
- Total sales: **₹6.09 Cr**, total profit: **₹49.7 L** (8.2% margin)
- 3,000 orders from 604 customers; average order value **₹20,294**
- Average delivery time: 4.5 days

## What the data says
1. **Growth:** sales grew 15% from 2023 to 2024.
2. **Seasonality:** the best month was November 2024 (₹42.5 L); October to December brings 36% of all sales.
3. **Categories:** Technology leads on sales, but Office Supplies has the best margin (16.5%) while Furniture has the lowest (2.5%).
4. **Loss-makers:** Tables (-₹6.2 L), Machines (-₹1.0 L). These sell, but lose money overall.
5. **Regions:** West has the best margin (10.2%); East has the weakest (3.6%).
6. **Discounts:** orders with 30%+ discount (19% of line items) earn a -5.4% margin versus 10.7% for the rest.
7. **Customers:** the top 10 customers account for 32% of sales.

## Recommendations
- Cap discounts at around 20% and require approval for anything deeper.
- Review pricing and discounting for the loss-making sub-categories before the next festive season.
- Build stock and marketing plans around October to December demand.
- Investigate why East margins lag (likely heavier discounting) and set regional discount limits.
- Run a loyalty or key-account programme for the top customers.
