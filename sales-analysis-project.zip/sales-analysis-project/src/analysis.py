# Retail Sales Analysis - beginner friendly version
#
# How to run (from the main project folder):
#     python src/analysis.py
#
# The script loads the sales data, checks it, calculates KPIs,
# saves 6 charts in the "images" folder and prints the key insights.
# All money values in charts are shown in lakhs (1 lakh = 100,000 rupees).

import os
import pandas as pd
import matplotlib.pyplot as plt

# ------------------------------------------------------------
# STEP 1: Load the data
# ------------------------------------------------------------
df = pd.read_csv("data/sales_data.csv")

# Convert the date columns from text to real dates
df["Order Date"] = pd.to_datetime(df["Order Date"])
df["Ship Date"] = pd.to_datetime(df["Ship Date"])

print("First 5 rows:")
print(df.head())

# ------------------------------------------------------------
# STEP 2: Check the data quality
# ------------------------------------------------------------
print("\nNumber of rows and columns:", df.shape)
print("Missing values:", df.isnull().sum().sum())
print("Duplicate rows:", df.duplicated().sum())

# ------------------------------------------------------------
# STEP 3: Add some useful new columns
# ------------------------------------------------------------
df["Year"] = df["Order Date"].dt.year
df["Month"] = df["Order Date"].dt.to_period("M")  # example: 2023-01
df["Ship Days"] = (df["Ship Date"] - df["Order Date"]).dt.days

# ------------------------------------------------------------
# STEP 4: Calculate the main KPIs
# ------------------------------------------------------------
total_sales = df["Sales"].sum()
total_profit = df["Profit"].sum()
profit_margin = total_profit / total_sales * 100
total_orders = df["Order ID"].nunique()  # nunique = number of unique values
total_customers = df["Customer ID"].nunique()
avg_order_value = total_sales / total_orders
avg_ship_days = df["Ship Days"].mean()

print("\n----- KPIs -----")
print("Total sales        : Rs", round(total_sales / 10000000, 2), "crore")
print("Total profit       : Rs", round(total_profit / 100000, 1), "lakh")
print("Profit margin      :", round(profit_margin, 1), "%")
print("Total orders       :", total_orders)
print("Total customers    :", total_customers)
print("Avg order value    : Rs", round(avg_order_value))
print("Avg delivery days  :", round(avg_ship_days, 1))

# Make a folder for the charts if it does not exist
os.makedirs("images", exist_ok=True)

# ------------------------------------------------------------
# STEP 5: Analysis and charts
# ------------------------------------------------------------

# --- Chart 1: Monthly sales and profit trend ---
monthly = df.groupby("Month")[["Sales", "Profit"]].sum()
monthly = monthly / 100000  # convert to lakhs

plt.figure(figsize=(10, 5))
plt.plot(monthly.index.astype(str), monthly["Sales"], marker="o", label="Sales")
plt.plot(monthly.index.astype(str), monthly["Profit"], marker="o", label="Profit")
plt.title("Monthly Sales and Profit")
plt.xlabel("Month")
plt.ylabel("Amount (Rs lakh)")
plt.xticks(rotation=60)
plt.legend()
plt.tight_layout()
plt.savefig("images/01_monthly_trend.png")
plt.close()

# --- Chart 2: Sales and profit by category ---
category = df.groupby("Category")[["Sales", "Profit"]].sum()
category = category / 100000

category.plot(kind="bar", figsize=(8, 5))
plt.title("Sales and Profit by Category")
plt.xlabel("Category")
plt.ylabel("Amount (Rs lakh)")
plt.xticks(rotation=0)
plt.tight_layout()
plt.savefig("images/02_category_sales_profit.png")
plt.close()

# --- Chart 3: Profit by sub-category (red = loss) ---
sub_profit = df.groupby("Sub-Category")["Profit"].sum().sort_values()
sub_profit = sub_profit / 100000

colors = []
for value in sub_profit:
    if value < 0:
        colors.append("red")
    else:
        colors.append("green")

sub_profit.plot(kind="barh", color=colors, figsize=(8, 6))
plt.title("Profit by Sub-Category (red = loss)")
plt.xlabel("Profit (Rs lakh)")
plt.tight_layout()
plt.savefig("images/03_subcategory_profit.png")
plt.close()

# --- Chart 4: Sales by region ---
region = df.groupby("Region")[["Sales", "Profit"]].sum()
region["Margin %"] = region["Profit"] / region["Sales"] * 100
region = region.sort_values("Sales", ascending=False)

(region["Sales"] / 100000).plot(kind="bar", figsize=(8, 5), color="steelblue")
plt.title("Sales by Region")
plt.xlabel("Region")
plt.ylabel("Sales (Rs lakh)")
plt.xticks(rotation=0)
plt.tight_layout()
plt.savefig("images/04_region_performance.png")
plt.close()

# --- Chart 5: Profit margin at each discount level ---
discount = df.groupby("Discount")[["Sales", "Profit"]].sum()
discount["Margin %"] = discount["Profit"] / discount["Sales"] * 100

discount["Margin %"].plot(kind="bar", figsize=(8, 5), color="orange")
plt.title("Profit Margin by Discount Level")
plt.xlabel("Discount (0.1 = 10%)")
plt.ylabel("Profit margin (%)")
plt.axhline(0, color="black")  # line at zero to see losses clearly
plt.xticks(rotation=0)
plt.tight_layout()
plt.savefig("images/05_discount_vs_margin.png")
plt.close()

# --- Chart 6: Top 10 customers by sales ---
top_customers = df.groupby("Customer ID")["Sales"].sum()
top_customers = top_customers.sort_values(ascending=False).head(10)

(top_customers.sort_values() / 100000).plot(kind="barh", figsize=(8, 5), color="steelblue")
plt.title("Top 10 Customers by Sales")
plt.xlabel("Sales (Rs lakh)")
plt.tight_layout()
plt.savefig("images/06_top_customers.png")
plt.close()

print("\n6 charts saved in the images folder")

# ------------------------------------------------------------
# STEP 6: Key insights
# ------------------------------------------------------------
print("\n----- KEY INSIGHTS -----")

# 1. Growth from 2023 to 2024
yearly_sales = df.groupby("Year")["Sales"].sum()
growth = (yearly_sales[2024] - yearly_sales[2023]) / yearly_sales[2023] * 100
print("1. Sales grew", round(growth), "% from 2023 to 2024")

# 2. Best month and festive season share (October to December)
best_month = monthly["Sales"].idxmax()
festive = df[df["Order Date"].dt.month >= 10]
festive_share = festive["Sales"].sum() / total_sales * 100
print("2. Best month:", best_month, "| Oct-Dec gives", round(festive_share), "% of all sales")

# 3. Category margins
category["Margin %"] = category["Profit"] / category["Sales"] * 100
print("3. Profit margin by category:")
print(category["Margin %"].round(1))

# 4. Loss-making sub-categories
losses = sub_profit[sub_profit < 0]
print("4. Loss-making sub-categories (Rs lakh):")
print(losses.round(1))

# 5. Region margins
print("5. Profit margin by region:")
print(region["Margin %"].round(1))

# 6. Effect of heavy discounts (30% or more)
heavy = df[df["Discount"] >= 0.3]
others = df[df["Discount"] < 0.3]
heavy_margin = heavy["Profit"].sum() / heavy["Sales"].sum() * 100
others_margin = others["Profit"].sum() / others["Sales"].sum() * 100
print("6. Margin with 30%+ discount:", round(heavy_margin, 1), "%")
print("   Margin with lower discount:", round(others_margin, 1), "%")

# 7. How much the top 10 customers contribute
top10_share = top_customers.sum() / total_sales * 100
print("7. Top 10 customers give", round(top10_share), "% of total sales")
